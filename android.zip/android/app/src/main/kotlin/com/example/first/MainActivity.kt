package com.example.first

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity() {
}
//package com.example.first
//
//import io.flutter.embedding.android.FlutterActivity
//
//class MainActivity: FlutterActivity()
